# -*- coding: utf-8 -*-
{
    'name': "Fatmug vendor self service portal",

    'summary': """""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Mohammad Iqbal Dar",
    'maintainer': "dar.iqbal.100@gmail.com",
    'category': 'Uncategorized',
    'version': '16.0.1',
    'depends': ['base', 'sale_management', 'product', 'portal'],

    'data': [
        'security/view_permission.xml',
        'security/ir.model.access.csv',
        'data/vendorAdjustmentRequest_mail.xml',
        'report/vendor_forecast_report.xml',
        'views/vendor_forcast_views.xml',
        'wizard/vendor_adjustment_requests_views.xml',
        'views/vendor_forcast_portal_view.xml',

    ],
    'auto_install': False,
    "installable": True,
    'application': True,
}
