from odoo import models, fields, api


class VendorAdjustmentRequest(models.TransientModel):
    _name = 'vendor.adjustment.request'
    _description = 'Vendor Adjustment Request'
    _rec_name = 'order_id'

    vendor_id = fields.Many2one('res.partner', string='Vendor')
    order_id = fields.Many2one('sale.order', string='Order')
    adjustment_detail = fields.Text(string='Adjustment Detail')
    comment = fields.Text(string='Comment')

    @api.model
    def default_get(self, fields):
        defaults = super(VendorAdjustmentRequest, self).default_get(fields)
        # Set default value for vendor_id to current user's partner_id
        defaults['vendor_id'] = self.env.user.partner_id.id
        return defaults

    # this method will take values from the wizard  and save them and generate an automated mail
    def save_adjustment_request(self):
        email_template = self.env.ref('vendor_self_service_portal.sending_vendor_adjustment_request_email')
        self.env['mail.template'].browse(email_template.id).send_mail(self.id, force_send=True)
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'target': 'new',
            'params': {
                'type': 'success',
                'sticky': False,
                'message': "Adjustment request has been created successfully.",
                'next': {'type': 'ir.actions.act_window_close'},
            }
        }
