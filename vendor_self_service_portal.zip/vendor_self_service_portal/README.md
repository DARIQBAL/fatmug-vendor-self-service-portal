# **How to install the "Vendor Self-Service Portal"**

1. Download the module package.

2. Locate the downloaded ZIP file and extract its contents to a folder on your computer.

3. Access the directory where Odoo add-ons are stored. This directory is typically named "addons" and is located within your Odoo installation directory.

4. Copy the extracted module folder (e.g., vendor_self_service_portal) to the Odoo add-ons directory.

5. Restart your Odoo server to apply changes and ensure the newly added module is recognized.

6. Open your web browser and enter the URL to access your Odoo instance.

7. Log in to the Odoo web interface using administrative credentials.

8. Once logged in, navigate to the "Apps" module from the top menu.

9. Click on the "Update Apps List" button to refresh the list of available modules.

10. Use the search bar or browse through categories to find the "Vendor Self-Service Portal" module.

11. Click on the module to view its details, then click the "Install" button to start the installation process.

###### **After installing the "Vendor Self-Service Portal" module, follow these steps to configure and use it effectively:**

# **Assign Users to the "is_vendor" Group:**
1. Go to the "Settings" module in Odoo.
2. Under the "Users & Companies" section, click on "Users".
3. Select the user(s) who should have vendor access.
4. Edit the user(s) and assign them to the "is_vendor" group.
5. Save the changes.


# **Features**


### **Forecast Viewing Portal:**
1. Vendors have access to a dedicated portal view where they can conveniently view upcoming demand forecasts for the next quarter.

2. The portal view includes sorting and filtering features, allowing vendors to organize and narrow down the displayed forecasts based on their preferences.

3. Vendors are restricted from creating, updating, or deleting records. They can only view their own records.

4. Admin users have full access and can view all records without any restrictions.

5. Access rights and record rules have been implemented to enforce these restrictions:
   5.1 Vendors belong to the 'is_vendor' group, which limits their access to view-only permissions.
   5.2 Admin users are not assigned to the 'is_vendor' group, granting them unrestricted access to view, update, create, and delete records.

   
# **Forecast Reporting Functionality:**
### **Form View Reporting:**
1. Vendors have the option to download reports in either XLSX or PDF format directly from the form view of the vendor forecast.
2. This feature provides vendors with the flexibility to choose their preferred format for downloading reports based on their needs and preferences.
### **List View Reporting(Server Action):**
1. In the list view of vendor forecasts, vendors have the option to download single or multiple reports in PDF format using a server action.
2. This functionality enables vendors to efficiently generate and download reports for individual forecasts or multiple forecasts at once, enhancing their productivity.




### **Vendor Adjustment Request Wizard:**
1. Vendors can submit adjustment requests for existing orders through a user-friendly wizard interface.
2. The wizard guides vendors through the process of providing details such as order reference, requested adjustments, and additional comments.
3. Upon submission of the request, a confirmation pop-up message is displayed to inform the vendor that the request has been successfully sent.

#### **Automated Email Notification:**
1. An automated email notification is triggered upon submission of the adjustment request, notifying Fatmug Designs' procurement team.
2. The email contains relevant details of the request, enabling the procurement team to review and take necessary actions promptly.


# **Author**
Name : Mohammad Iqbal Dar
email : dar.iqbal.100@gmail.com
mobile no : +91 7006416439





