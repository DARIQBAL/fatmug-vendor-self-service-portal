from odoo import models, fields, api
import xlwt
from io import BytesIO
import base64
from lxml import etree

class VendorForecast(models.Model):
    _name = 'vendor.forecast'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'Vendor Forecast'
    _rec_name = 'product_id'

    vendor_id = fields.Many2one('res.partner',string='Vendor',tracking=True)
    product_id = fields.Many2one('product.product', string='Product',tracking=True)
    expected_quantity = fields.Integer(string='Expected Quantity',tracking=True)
    forecast_date = fields.Date(string='Forecast Date',tracking=True)

    @api.model
    def get_view(self, view_id=None, view_type='form', **options): #inherit get_view method to hide create,update and delete buttons if user  has is_vendor group for security
        """
            Override method for hide edit button (vendor forecast create,delete and edit)
        """
        res = super(VendorForecast, self).get_view(
            view_id=view_id, view_type=view_type,options=options)
        # if view_type == 'tree':
        if  self.env.user.has_group('vendor_self_service_portal.group_is_vendor'):
            root = etree.fromstring(res['arch'])
            root.set('edit', 'false')
            root.set('create', 'false')
            root.set('delete', 'false')
            res['arch'] = etree.tostring(root).decode('utf-8')
        return res



    @api.model
    def default_get(self, fields): #inherit default_get method to set vendor_id by default to current user
        defaults = super(VendorForecast, self).default_get(fields)
        # Set default value for vendor_id to current user's partner_id
        defaults['vendor_id'] = self.env.user.partner_id.id
        return defaults

    # get base url to open portal view from menu
    def get_custom_url(self):
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            base_url = base_url + "/my"
            return {
                'type': 'ir.actions.act_url',
                'target': 'new',
                'url': base_url,
            }


    # this method is used to  generate pdf report for vendor forecast model
    def generate_pdf_report_forecast(self):
        return self.env.ref("vendor_self_service_portal.action_report_vendor_forecast").report_action(self)

    # this method is used to  generate xlsx report for vendor forecast model
    def generate_xlxs_report_forecast(self):
        workbook = xlwt.Workbook()
        sheet = workbook.add_sheet('Forecast Report',cell_overwrite_ok=True)
        header_bold = xlwt.easyxf("font: bold on, height 500;align: vert centre, horiz center;")
        format1 = xlwt.easyxf("font:bold on,height 250;align:vert center, horiz left;")

        row = 0
        col = 0
        sheet.write_merge(row, col, row, col + 7, 'DEMAND FORECAST XLXS REPORT', header_bold)
        row += 2
        col = 0
        sheet.col(0).width = int(40 * 260)
        sheet.col(1).width = int(40 * 260)
        sheet.col(2).width = int(30 * 260)
        sheet.col(3).width = int(30 * 260)
        sheet.write(row, 0, 'Vendor Name', format1)
        sheet.write(row, 1, 'Product Name',format1)
        sheet.write(row, 2, 'Forecast Date', format1)
        sheet.write(row, 3, 'Expected Quantity',format1)

        row = 3
        for data in self:
            sheet.write(row, 0, data.vendor_id.name)
            sheet.write(row, 1, data.product_id.name)
            sheet.write(row, 2, str(data.forecast_date))
            sheet.write(row, 3, data.expected_quantity)

            row += 1
        output = BytesIO()
        workbook.save(output)
        output.seek(0)
        datas = base64.b64encode(output.read())
        output.close()
        attach_vals = {
            'name': '%s.xls' % ('Forecast Report'),
            'datas': datas,
        }
        report_id = self.env['ir.attachment'].create(attach_vals)
        return {
            "target": 'self',
            "type": "ir.actions.act_url",
            "url": 'web/content/%s?download=true' % (report_id.id)
        }


