from odoo.addons.portal.controllers.portal import CustomerPortal, pager
from odoo.http import request
from odoo import http
from odoo import fields, _
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
from odoo.tools import date_utils
from collections import defaultdict, OrderedDict


# portal views for forecast details model
# inherits CustomerPortal class from portal module
class VendorForecastPortal(CustomerPortal):
    #  inherits this method from CustomerPortal class and sets vendorForecastCount counter which will be shown on forecast menu in portal view
    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        vendor_forecast = request.env['vendor.forecast']
        if 'vendor_forecast_count' in counters:
            current_user = request.env.user  # get current logged user
            if current_user.has_group(
                    'base.group_erp_manager'):  # check if current user is admin So he can view all records count
                values['vendor_forecast_count'] = vendor_forecast.search_count([])
            else:
                values['vendor_forecast_count'] = vendor_forecast.search_count(
                    [('vendor_id', '=', current_user.partner_id.id)])  # vendor can view only his/her record count
            # values['vendor_forecast_count'] = vendorForecastCount
        return values

    #  list view for vendor forecast
    @http.route(['/my/vendor_forecast', '/my/vendor_forecast/page/<int:page>'], type='http', website=True,
                auth='user')
    def vendor_forecast_list_view(self, page=1, sortby=None, filterby=None, **kwargs):

        current_user = request.env.user
        vendor_forecast = request.env['vendor.forecast']

        if current_user.has_group('base.group_erp_manager'):
            records = vendor_forecast.search_count([])
        else:
            records = vendor_forecast.search_count([('vendor_id', '=', current_user.partner_id.id)])

        today = fields.Date.today()  # get current date
        quarter_start, quarter_end = date_utils.get_quarter(today)  # get quarter date from today

        domain = [('vendor_id', '=', current_user.partner_id.id)]  # vendor can view only his/her records (condition)

        # for Sorting feature in portal view for vendor.
        # vendor can sort using id,product name,expected quantity and forecast date in ascending or descending order default sort is 'id'.
        searchbar_sortings = {
            'id': {'label': _('ID'), 'order': 'id desc'},
            'product_id': {'label': _('Product Name'), 'order': 'product_id'},
            'expected_quantity': {'label': _('Expected Quantity'), 'order': 'expected_quantity desc'},
            'forecast_date': {'label': _('Forecast Date'), 'order': 'forecast_date '}
        }

        # for filtering feature in portal view for vendor. vendor can filter his/her records using all/today or quarter default filter is 'all'.
        searchbar_filters = {
            'all': {'label': _('All'), 'domain': []},
            'today': {'label': _('Today'), 'domain': [("forecast_date", "=", today)]},
            'quarter': {'label': _('This Quarter'),
                        'domain': [('forecast_date', '>=', quarter_start), ('forecast_date', '<=', quarter_end)]},
        }

        if not filterby:
            filterby = 'all'

        if not sortby:
            sortby = 'id'

        filter_domain = searchbar_filters.get(filterby, {}).get('domain', [])
        default_order_by = searchbar_sortings.get(sortby, {}).get('order')

        domain += filter_domain

        # inherit pager form portal to add our custom logic for pagination
        page_detail = pager(url='/my/vendor_forecast',
                            total=records,
                            page=page,
                            url_args={'sortby': sortby, 'filterby': filterby},
                            step=5)

        if current_user.has_group('base.group_erp_manager'):
            total_records = vendor_forecast.search(filter_domain, limit=5,
                                                   order=default_order_by,
                                                   offset=page_detail['offset'])
        else:
            total_records = vendor_forecast.search(domain,
                                                   limit=5,
                                                   order=default_order_by,
                                                   offset=page_detail['offset'])

        # sending data to list portal view
        vals = {
            'records': total_records,
            'page_name': 'vendor_forecast_list',
            'pager': page_detail,
            'default_url': '/my/vendor_forecast',
            'searchbar_sortings': searchbar_sortings,
            'sortby': sortby,
            'filterby': filterby,
            'searchbar_filters': searchbar_filters
        }
        return request.render("vendor_self_service_portal.vendor_forecast_list_view_portal", vals)
